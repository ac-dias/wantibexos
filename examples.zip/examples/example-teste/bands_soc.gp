gnuplot

set terminal pngcairo color size 1000,2400 enhanced "Times New Roman,40.0"


set palette rgbformulae 33,13,10 negative




set style line 1 \
    linecolor rgb 'black' \
    linetype 1 linewidth 3 \
    pointtype 7 pointsize 1.5

set style line 2 dt '-' \
    linecolor rgb 'red' \
    linetype 1 linewidth 2 \
    pointtype 7 pointsize 1.5

set style line 3 \
    linecolor rgb 'blue' \
    linetype 1 linewidth 3 \
    pointtype 7 pointsize 1.5



set ylabel "Energy (eV)" font "Times-Roman,20"
#set xlabel "Energy-Efermi (eV)" font "Times-Roman,20"


set yrange[-7:7]
set xrange[0:1]
set cbrange[-1:1]

set tics font ", 20"




set output 'bands_soc.png'

unset key

set multiplot layout 3,1

#efermi= 1.0406



#set xtics ("{/Symbol G}" 0.000,"X" 0.1627,"M" 0.3254,"R" 0.4881,"{/Symbol G}" 0.7699,"M" 1.0)
set xtics ("{/Symbol G}" 0.000,"K" 0.3333334,"K'" 0.6666666,"{/Symbol G}" 1.0)

set arrow from  0.3333334,  -5.0 to  0.3333334,   5 nohead dt 2 linewidth 2
set arrow from  0.6666666,  -5.0 to  0.6666666,   5 nohead dt 2 linewidth 2



set arrow from  0.0,  0.0 to  1.0,   0.0 nohead dt 2 linewidth 2

set title '(a) Sz' font "Times-Roman,20"
plot './out-old/bands.dat' u 1:2:5 w linespoints pointtype 7 ps 0.1 lw 2 palette t " " \

set title '(b) Sx' font "Times-Roman,20"
plot './out-old/bands.dat' u 1:2:3 w linespoints pointtype 7 ps 0.1 lw 2 palette t " " \

set title '(c) Sy' font "Times-Roman,20"
plot './out-old/bands.dat' u 1:2:4 w linespoints pointtype 7 ps 0.1 lw 2 palette t " " \




unset multiplot

q
