#!/usr/bin/env bash

nthreads=1
wtbexec="wantibexos_folder/bin/wtb.x"

cat > kpoints.dat << EOF
12
150
0.50000     0.50000     0.50000 !L  
0.00000     0.00000     0.00000 !G
0.00000     0.00000     0.00000 !G 
0.50000     0.00000     0.50000 !X
0.50000     0.00000     0.50000 !X  
0.50000     0.25000     0.75000 !W
0.50000     0.25000     0.75000 !W
0.50000     0.50000     0.50000 !L
0.50000     0.50000     0.50000 !L  
0.75000     0.37500     0.37500 !K
0.75000     0.37500     0.37500 !K  
0.00000     0.00000     0.00000 !G
EOF

mkdir ./out

cat > em_input.dat     << EOF
 2
 C
         0.0000         0.0000         0.0000           4         0.0
         0.0000         0.0000         0.0000           5         0.8546

EOF

cat > input.dat     << EOF
NTHREADS= $nthreads
SYSDIM= "3D"
DFT= "V"

OUTPUT= "./out/"
CALC_DATA= "./out/"
PARAMS_FILE= "tb_gaas.dat"
KPATH_FILE= "kpoints.dat"
EM_FILE= "em_input.dat"
                                                             
BANDS= T                                                  
EM_TENSOR= T
dK= 0.15
	
EOF


$wtbexec < input.dat







